
const STRINGS = {
  es: {
    title: "🌐 La Biblioteca Mundial del Internet",
    subtitle: "Acceso libre al conocimiento global",
    entering: "📚 Entrando a la Biblioteca Mundial del Internet...",
    archive_section: "Secciones de Archive.org",
    other_section: "Otras Bibliotecas del Mundo",
    footer: "© 2025 La Biblioteca Mundial del Internet — Conocimiento libre para todos",
    search_placeholder: "Buscar en Archive.org (término)...",
    change_lang: "Español / English"
  },
  en: {
    title: "🌐 The World Internet Library",
    subtitle: "Free access to global knowledge",
    entering: "📚 Entering the World Internet Library...",
    archive_section: "Archive.org Sections",
    other_section: "World Libraries",
    footer: "© 2025 The World Internet Library — Free knowledge for everyone",
    search_placeholder: "Search Archive.org (term)...",
    change_lang: "Español / English"
  }
};

function t(k){ return STRINGS[LANG][k] || k; }

let LANG = navigator.language && navigator.language.startsWith('en') ? 'en' : 'es';
const savedLang = localStorage.getItem('bm_lang');
if(savedLang) LANG = savedLang;

let THEME = localStorage.getItem('bm_theme') || 'dark';
const applyTheme = (color)=>{
  const root = document.documentElement;
  if(color === 'light') {
    root.style.setProperty('--bg', '#ffffff');
    root.style.setProperty('--text', '#111827');
    root.style.setProperty('--muted', '#4b5563');
  } else if(color === 'purple') {
    root.style.setProperty('--accent', '#7c3aed');
  } else if(color === 'blue') {
    root.style.setProperty('--accent', '#1e88e5');
  } else if(color === 'green') {
    root.style.setProperty('--accent', '#2e7d32');
  } else if(color === 'red') {
    root.style.setProperty('--accent', '#c62828');
  } else {
    root.style.setProperty('--bg', '#000000');
    root.style.setProperty('--text', '#ffffff');
    root.style.setProperty('--muted', '#9aa0a6');
    root.style.setProperty('--accent', '#1e88e5');
  }
  localStorage.setItem('bm_theme', color);
  THEME = color;
};

document.addEventListener('DOMContentLoaded', ()=>{
  document.getElementById('langBtn').addEventListener('click', ()=>{
    LANG = LANG === 'es' ? 'en' : 'es';
    localStorage.setItem('bm_lang', LANG);
    renderText();
  });
  applyTheme(localStorage.getItem('bm_theme') || 'dark');
  document.querySelectorAll('.color-dot').forEach(dot=>{
    dot.addEventListener('click', ()=> applyTheme(dot.dataset.color));
  });

  document.getElementById('searchBtn').addEventListener('click', ()=>{
    const q = document.getElementById('searchInput').value.trim();
    if(q) window.open('https://archive.org/search.php?query=' + encodeURIComponent(q), '_blank');
  });

  document.querySelectorAll('.card').forEach(card=>{
    card.addEventListener('click', ()=>{
      const url = card.dataset.url;
      if(url) window.open(url, '_blank');
    });
  });

  setTimeout(()=>{
    document.getElementById('loader').style.display='none';
    document.getElementById('app').style.display='block';
    renderText();
  }, 1600);
});

function renderText(){
  document.getElementById('title').innerText = t('title');
  document.getElementById('subtitle').innerText = t('subtitle');
  document.getElementById('archive_label').innerText = t('archive_section');
  document.getElementById('other_label').innerText = t('other_section');
  document.getElementById('footer').innerText = t('footer');
  document.getElementById('searchInput').placeholder = t('search_placeholder');
}
